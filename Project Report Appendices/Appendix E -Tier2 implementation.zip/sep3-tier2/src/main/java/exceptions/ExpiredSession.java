package exceptions;

public class ExpiredSession extends Exception {


	
	public ExpiredSession(String message) {
		super(message);
	}

}
